/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 17:22:57 by dhercula          #+#    #+#             */
/*   Updated: 2026/03/19 18:18:11 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int		i;

	i = 0;
	while (s1[i] == s2[i] && s1[i] != '\0')
		i++;
	return (s1[i] - s2[i]);
}
#include <stdio.h>
#include <string.h>

int		main(void)
{
	char	*s1 = "dzzzz";
	char	*s2 = "ba";

	printf("strcmp <string.h>: %d\n", strcmp(s1, s2));
	printf("funcao que criei: %d\n", ft_strcmp(s1, s2));
}
