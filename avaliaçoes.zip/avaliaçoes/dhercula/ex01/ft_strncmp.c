/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 17:23:37 by dhercula          #+#    #+#             */
/*   Updated: 2026/03/19 18:19:42 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int		i;

	i = 0;
	if (n == 0)
		return (0);
	while (i < n && s1[i] != '\0' && s2[i] != '\0'
		&& s1[i] == s2[i])
	{
		i++;
	}
	return (s1[i] - s2[i]);
}
#include <string.h>
#include <stdio.h>
int		main()
{
	char	*s1 = "testezinho";
	char	*s2 = "testizinho";
	int		n = 5;

	printf("funcao da <string.h>: %d\n", strncmp(s1, s2, n));
	printf("Funcao que criei: %d\n", ft_strncmp(s1, s2, n));
}
