/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 17:24:13 by dhercula          #+#    #+#             */
/*   Updated: 2026/03/19 18:20:28 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int		i;
	int		j;

	i = 0;
	while (dest[i] != '\0')
		i++;
	j = 0;
	while (src[j] != '\0')
	{
		dest[i + j] = src[j];
		j++;
	}
	dest[i + j] = '\0';
	return (dest);
}
#include <stdio.h>
#include <string.h>

int		main (void)
{
	char	s1[20] = "origem";
	char	s2[] = "teste";
	char	s3[20] = "origem";
	char	s4[] = "teste";

	printf("Funcao da <string.h>: %s\n", strcat(s1, s2));
	printf("Funcao que criei: %s\n", ft_strcat(s3, s4));
}
