/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lde-paul <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 10:33:42 by lde-paul          #+#    #+#             */
/*   Updated: 2026/03/19 16:15:00 by lde-paul         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char **argv)
{
	int	index;

	if (argc >= 0)
	{
		index = 0;
		while (argv[0][index])
		{
			write(1, &argv[0][index], 1);
			index++;
		}
		write(1, "\n", 1);
	}
	return (0);
}
