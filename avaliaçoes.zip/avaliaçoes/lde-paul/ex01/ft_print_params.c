/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lde-paul <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 15:49:50 by lde-paul          #+#    #+#             */
/*   Updated: 2026/03/19 16:17:48 by lde-paul         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char **argv)
{
	int	index_arg;
	int	index_word;

	if (argc >= 1)
	{
		index_arg = 1;
		while (argv[index_arg])
		{
			index_word = 0;
			while (argv[index_arg][index_word])
			{
				write(1, &argv[index_arg][index_word], 1);
				index_word++;
			}
			write(1, "\n", 1);
			index_arg++;
		}
	}
	return (0);
}
