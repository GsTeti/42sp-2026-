git log --format=%H
