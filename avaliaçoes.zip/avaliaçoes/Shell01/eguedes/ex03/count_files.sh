find . | wc -l
