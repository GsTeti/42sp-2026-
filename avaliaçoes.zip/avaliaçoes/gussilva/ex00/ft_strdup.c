/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 13:39:15 by gussilva          #+#    #+#             */
/*   Updated: 2026/03/19 15:21:15 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strdup(char *src)
{
	char	*srccop;
	int		len;
	int		i;

	if (src == 0)
		return (0);
	len = 0;
	while (src[len])
		len++;
	srccop = (char *)malloc(sizeof(char) * (len + 1));
	if (srccop == 0)
		return (0);
	i = 0;
	while (i < len)
	{
		srccop[i] = src[i];
		i++;
	}
	srccop[i] = '\0';
	return (srccop);
}

// #include <stdio.h>

// int	main(void)
// {
// 	char *src = "Ola Mundo";
// 	char *srccop = ft_strdup(src);

// 	if (*srccop != 0)
// 	{
// 		printf("Original: %s\n", src);
// 		printf("Copia: %s\n", srccop);
// 	}

// 	return (0);
// }
