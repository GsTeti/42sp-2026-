/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 11:31:02 by gussilva          #+#    #+#             */
/*   Updated: 2026/03/19 15:22:31 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	len;
	int	i;

	i = 0;
	len = max - min;
	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	*range = (int *)malloc(len * sizeof(int));
	while (i < len)
	{
		(*range)[i] = min + i;
		i++;
	}
	return (len);
}

// #include <stdio.h>
// int	main(void)
// {
// 	int	*arr;
// 	int	i;
// 	int 	size;

// 	i = 0;
// 	size = ft_ultimate_range(&arr, 3, 8);

// 	while (i < size)
// 	{
// 		printf("%d\n", arr[i]);
// 		i++;
// 	}
// 	free(arr);
// 	return (0);
// }
