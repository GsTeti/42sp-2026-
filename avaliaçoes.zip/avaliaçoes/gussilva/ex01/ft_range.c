/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gussilva <gussilva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 11:23:52 by gussilva          #+#    #+#             */
/*   Updated: 2026/03/19 11:31:59 by gussilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*array;
	int	size;
	int	i;

	if (min >= max)
		return (0);
	size = max - min + 1;
	array = (int *)malloc(sizeof(int) * size);
	if (array == 0)
		return (0);
	i = 0;
	while (i < size)
	{
		array[i] = min + i;
		i++;
	}
	return (array);
}

// #include <stdio.h>
// int main (void)
// {
// 	int *arr;
// 	int i;

// 	arr = ft_range(1, 5);
// 	i = 0;
// 	while(arr[i])
// 	{
// 		printf("%d, ", arr[i]);
// 		i++;
// 	}
// 	return (0);
// }
