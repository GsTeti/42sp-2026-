/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gussilva <gussilva@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 11:55:53 by gussilva          #+#    #+#             */
/*   Updated: 2026/03/19 13:14:27 by gussilva         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int ft_strlen(char *str)
{
	int i;
	
	i = 0;
	while(str[i])
		i++;
	return(i);
}

int ft_tot_strs_len(char **str, int size)
{
	int i;
	int tl_len;
	
	i = 0;
	tl_len = 0;
	while(i < size)
	{
		tl_len += (ft_strlen(str[i]));
		i++;
	}
	return (tl_len);
}

char *ft_strcat(char *dest, char *src)
{
	char *dest_final;
	
	dest_final = dest;
	while (*dest)
		dest++;
	while (*src)
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (dest_final);
}

char	*ft_strjoin(int size, char **str, char *sep)
{
	int		str_size;
	int		i;
	char	*str_join;

	if (size == 0)
	{
		str_join = (char *)malloc(2);
		str_join[0] = '\0';
		return (str_join);
	}
	str_size = ft_tot_strs_len(str, size) + (size - 1) * ft_strlen(sep);
	str_join = (char *)malloc(str_size + 1);
	str_join[0] = '\0';
	i = 0;
	while (i < size)
	{
		ft_strcat(str_join, str[i]);
		if (i < size - 1)
			ft_strcat(str_join, sep);
		i++;
	}
	return (str_join);
}

// #include <stdio.h>
// #include <stdlib.h>

// // Protótipo da sua função
// char *ft_strjoin(int size, char **strs, char *sep);

// int main(void)
// {
//    // Teste 1: Comportamento normal com um separador comum
//    char *strs1[] = {"Ola", "mundo", "maravilhoso", "do", "C"};
//    char *sep1 = " --- ";
//    char *res1 = ft_strjoin(5, strs1, sep1);
//    printf("Teste 1 (Normal): '%s'\n", res1);
//    free(res1);

//    // Teste 2: Separador vazio (strings devem ficar coladas)
//    char *strs2[] = {"Juntando", "tudo", "sem", "espacos"};
//    char *sep2 = "";
//    char *res2 = ft_strjoin(4, strs2, sep2);
//    printf("Teste 2 (Separador vazio): '%s'\n", res2);
//    free(res2);

//    // Teste 3: Size = 0
//    // O ponteiro strs3 não deve sequer ser acessado se size for 0
//    char *strs3[] = {"Isso", "nao", "deve", "imprimir"};
//    char *sep3 = " - ";
//    char *res3 = ft_strjoin(0, strs3, sep3);
//    if (res3 != NULL)
//    {
//        printf("Teste 3 (Size 0): '%s'\n", res3);
//        free(res3);
//    }
//    else
//    {
//        printf("Teste 3 (Size 0): ERRO! NULL em vez de string vazia aloc.\n");
//    }

//    // Teste 4: Size = 1 (Deve retornar apenas a primeira string, sem sep)
//    char *strs4[] = {"Solitario"};
//    char *sep4 = " + ";
//    char *res4 = ft_strjoin(1, strs4, sep4);
//    printf("Teste 4 (Size 1): '%s'\n", res4);
//    free(res4);

//    return 0;
// }