/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mamatos- <mamatos-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 21:03:38 by mamatos-          #+#    #+#             */
/*   Updated: 2026/03/19 21:15:06 by mamatos-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nb)
{
	int		valor_unidade;
	long	n;

	n = nb;
	if (n < 0)
	{
		write(1, "-", 1);
		n *= -1;
	}
	if (n >= 0 && n <= 9)
	{
		valor_unidade = n % 10 + '0';
		write(1, &valor_unidade, 1);
	}
	else
	{
		valor_unidade = n % 10 + '0';
		n = n / 10;
		ft_putnbr(n);
		write(1, &valor_unidade, 1);
	}
}

// int main(void)
// {
// 	ft_putnbr(-65);
// }