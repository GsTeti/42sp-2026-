/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mamatos- <mamatos-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 21:03:43 by mamatos-          #+#    #+#             */
/*   Updated: 2026/03/19 21:14:29 by mamatos-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_atoi(char *str)
{
	int	valor;
	int	sinal;
	int	i;

	sinal = 1;
	i = 0;
	valor = 0;
	while (str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
		i++;
	while (str[i] == 45 || str[i] == 43)
	{
		if (str[i] == 45)
			sinal *= -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		valor = (valor * 10) + (str[i] - 48);
		i++;
	}
	return (valor * sinal);
}

// #include <stdio.h>

// int main(void)
// {
//     printf("%d", ft_atoi("-123"));
// }