/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: karenrod <karenrod@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 14:10:47 by karenrod          #+#    #+#             */
/*   Updated: 2026/03/19 14:11:15 by karenrod         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 32 && str[i] <= 126))
		{
			return (0);
		}
		i++;
	}
	return (1);
}

// int	main(void)
// {
// 	char	*teste1;
// 	char	*teste2;
// 	char	*teste3;
// 	char	*teste4;
// 	char	*teste5;

// 	teste1 = "!";
// 	teste2 = "*";
// 	teste3 = " ";
// 	teste4 = "";
// 	teste5 = "\06";
// 	printf("teste1:%d\n", ft_str_is_printable(teste1));
// 	printf("teste2:%d\n", ft_str_is_printable(teste2));
// 	printf("teste3:%d\n", ft_str_is_printable(teste3));
// 	printf("teste4:%d\n", ft_str_is_printable(teste4));
// 	printf("teste5:%d\n", ft_str_is_printable(teste5));
// 	return (0);
// }
