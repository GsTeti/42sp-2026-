/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: karenrod <karenrod@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 14:13:25 by karenrod          #+#    #+#             */
/*   Updated: 2026/03/19 14:15:44 by karenrod         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			str[i] = str[i] +32;
		}
		i++;
	}
	return (str);
}

// int	main(void)
// {
// 	char	test[6];

// 	test[0] = 'K';
// 	test[1] = 'A';
// 	test[2] = 'R';
// 	test[3] = 'E';
// 	test[4] = 'N';
// 	test[5] = '\0';
// 	printf("test:%s\n", ft_strlowcase(test));
// 	return (0);
// }
