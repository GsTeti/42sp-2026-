/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: karenrod <karenrod@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 14:06:16 by karenrod          #+#    #+#             */
/*   Updated: 2026/03/19 14:07:00 by karenrod         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= '0' && str[i] <= '9'))
			return (0);
		i++;
	}
	return (1);
}

// int	main(void)
// {
// 	char	*teste1;
// 	char	*teste2;
// 	char	*teste3;

// 	teste1 = "31";
// 	teste2 = "";
// 	teste3 = "Abc";
// 	printf("teste1:%d\n", ft_str_is_numeric(teste1));
// 	printf("teste2:%d\n", ft_str_is_numeric(teste2));
// 	printf("teste3:%d\n", ft_str_is_numeric(teste3));
// 	return (0);
// }
