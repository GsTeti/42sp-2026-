/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: karenrod <karenrod@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 13:44:37 by karenrod          #+#    #+#             */
/*   Updated: 2026/03/19 14:02:33 by karenrod         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (src[i] != '\0' && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}

// int	main(void)
// {
// 	char	origem [] = "Eu me remexo muito";
// 	char	destino [30];
// 	unsigned int	n;

// 	n = 25;
// 	printf("Sem frase declarada, por isso, vazio:%s\n", destino);
// 	ft_strncpy(destino, origem, n);
// 	printf("Após a função, a frase é:%s\n", destino);
// 	return (0);
// }
