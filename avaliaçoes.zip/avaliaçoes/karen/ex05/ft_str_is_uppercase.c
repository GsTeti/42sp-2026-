/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: karenrod <karenrod@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/19 14:09:14 by karenrod          #+#    #+#             */
/*   Updated: 2026/03/19 14:09:47 by karenrod         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'A' && str[i] <= 'Z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}

// int	main(void)
// {
// 	char	*teste1;
// 	char	*teste2;
// 	char	*teste3;
// 	char	*teste4;

// 	teste1 = "KAREN";
// 	teste2 = "karen";
// 	teste3 = "1234";
// 	teste4 = "";
// 	printf("teste1:%d\n", ft_str_is_uppercase(teste1));
// 	printf("teste2:%d\n", ft_str_is_uppercase(teste2));
// 	printf("teste3:%d\n", ft_str_is_uppercase(teste3));
// 	printf("teste4:%d\n", ft_str_is_uppercase(teste4));
// 	return (0);
// }
