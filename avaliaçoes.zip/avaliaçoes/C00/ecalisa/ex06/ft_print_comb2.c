/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/26 14:58:21 by ecallisa          #+#    #+#             */
/*   Updated: 2026/03/01 19:49:27 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_put_number(char num)
{
	char	d;
	char	u;

	d = (num / 10) + '0';
	u = (num % 10) + '0';
	write(1, &d, 1);
	write(1, &u, 1);
}

void	ft_print_comb2(void)
{
	int		num1;
	int		num2;

	num1 = 0;
	while (num1 <= 99)
	{
		num2 = num1 + 1;
		while (num2 <= 99)
		{
			ft_put_number(num1);
			write(1, " ", 1);
			ft_put_number(num2);
			if (num1 != 98)
			{
				write(1, ",", 1);
				write(1, " ", 1);
			}
			num2++;
		}
		num1++;
	}
}

int main() {
	ft_print_comb2();
	return 0;
}
