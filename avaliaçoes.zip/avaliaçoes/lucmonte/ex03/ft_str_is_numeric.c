/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lucmonte <lucmonte@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 15:10:43 by lucmonte          #+#    #+#             */
/*   Updated: 2026/03/19 11:09:29 by lucmonte         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_str_is_numeric(char *str);

int	ft_str_is_numeric(char *str)
{
	int		i;

	i = 0;
	while (str[i])
	{
		if (!(str[i] >= '0' && str[i] <= '9'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
// #include <stdio.h>
// int main (void)
// {
// 	char	str[] = "12e45";
// 	char	r;
// 	r = ft_str_is_numeric(str);
// 	printf("%i\n", r);
// 	return(0);
// }