/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lucmonte <lucmonte@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 15:10:24 by lucmonte          #+#    #+#             */
/*   Updated: 2026/03/19 11:13:08 by lucmonte         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_str_is_uppercase(char *str);

int	ft_str_is_uppercase(char *str)
{
	int		i;

	i = 0;
	while (str[i])
	{
		if (!(str[i] >= 'A' && str[i] <= 'Z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
// #include <stdio.h>
// int main (void)
// {
// 	char	str[] = "AbC";
// 	char	r;
// 	r = ft_str_is_uppercase(str);
// 	printf("%i\n", r);
// 	return(0);
// }