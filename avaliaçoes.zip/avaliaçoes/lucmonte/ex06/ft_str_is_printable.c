/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lucmonte <lucmonte@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/18 15:12:19 by lucmonte          #+#    #+#             */
/*   Updated: 2026/03/19 11:15:25 by lucmonte         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_str_is_printable(char *str);

int	ft_str_is_printable(char *str)
{
	int		i;

	i = 0;
	while (str[i])
	{
		if (!(str[i] >= 32 && str[i] <= 126))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
// #include <stdio.h>
// int main (void)
// {
// 	char	str[] = "123\n";
// 	char	r;
// 	r = ft_str_is_printable(str);
// 	printf("%i\n", r);
// 	return(0);
// }
