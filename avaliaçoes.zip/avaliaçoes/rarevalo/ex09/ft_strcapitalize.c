/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 19:42:19 by rarevalo          #+#    #+#             */
/*   Updated: 2026/03/19 20:27:24 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_is_alphanum(char c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
	{
		return (1);
	}
	if (c >= '0' && c <= '9')
	{
		return (1);
	}
	return (0);
}

void	ft_putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}

char	*ft_strcapitalize(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if ((i == 0 || !ft_is_alphanum(str[i - 1])))
		{
			if (str[i] >= 'a' && str[i] <= 'z')
			{
				str[i] -= 32;
			}
		}
		else if (i > 0 && ft_is_alphanum(str[i - 1]))
		{
			if (str[i] >= 'A' && str[i] <= 'Z')
			{
				str[i] += 32;
			}
		}
		i++;
	}
	return (str);
}

int	main(void)
{
	char str1[] = "hi, how are you? 42words forty-two; fifty+and+one";
	char str2[] = "vou lOgo ALI";

	ft_putstr("Original 1: ");
	ft_putstr(str1);
	ft_putstr("\n");
	ft_strcapitalize(str1);
	ft_putstr("Modificado 1: ");
	ft_putstr(str1);
	ft_putstr("\n\n");

	ft_putstr("Original 2: ");
	ft_putstr(str2);
	ft_putstr("\n");
	ft_strcapitalize(str2);
	ft_putstr("Modificado 2: ");
	ft_putstr(str2);
	ft_putstr("\n");

	return (0);
}
