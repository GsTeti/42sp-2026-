/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 16:25:31 by rarevalo          #+#    #+#             */
/*   Updated: 2026/03/19 20:25:52 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 36 && str[i] <= 126))
		{
			return (0);
		}
		i++;
	}
	return (1);
}

#include <stdio.h>
int  main(void)
{
	char str_s[] = "z";
    char str_n[] = "\n";
    printf("%d", ft_str_is_printable(str_s));
	printf("\n");
	printf("%d \n", ft_str_is_printable(str_n));
    return (0);
}
