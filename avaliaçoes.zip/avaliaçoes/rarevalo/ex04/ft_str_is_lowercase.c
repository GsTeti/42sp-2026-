/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/15 18:25:58 by rarevalo          #+#    #+#             */
/*   Updated: 2026/03/19 20:24:39 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}

#include <stdio.h>
int  main(void)
{
	char str_s[] = "z";
    char str_n[] = "12";
    printf("%d", ft_str_is_lowercase(str_s));
	printf("\n");
	printf("%d \n", ft_str_is_lowercase(str_n));
    return (0);
}
