/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/17 16:05:32 by rarevalo          #+#    #+#             */
/*   Updated: 2026/03/19 20:25:25 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'A' && str[i] <= 'Z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}

#include <stdio.h>
int  main(void)
{
	char str_s[] = "A";
    char str_n[] = "12";
    printf("%d", ft_str_is_uppercase(str_s));
	printf("\n");
	printf("%d \n", ft_str_is_uppercase(str_n));
    return (0);
}
