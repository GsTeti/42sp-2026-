/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/05 09:24:23 by matrodri          #+#    #+#             */
/*   Updated: 2026/03/19 21:38:16 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
		*div = a / b;
		*mod = a % b;
}

#include <stdio.h>
int main(void)
{
	int num1;
	int num2;
	int result;
	int rest;

	num1 = 23;
	num2 = 7;
	ft_div_mod(num1, num2, &result, &rest);
	printf("\t\nResultado da divisão: %d", result);
	printf("\t\nResultado do resto da divisão: %d", rest);
}
