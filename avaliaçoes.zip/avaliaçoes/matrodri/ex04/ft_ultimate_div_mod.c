/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gstefani <gstefani@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/05 09:58:50 by matrodri          #+#    #+#             */
/*   Updated: 2026/03/19 21:38:20 by gstefani         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int *a, int *b)
{
	int	aux1;
	int	aux2;

	aux1 = *a;
	aux2 = *b;
	*a = aux1 / *b;
	*b = aux2 % *b;
}

#include <stdio.h>
int main(void)
{
	int num1;
	int num2;

	num1 = 70;
	num2 = 80;
	ft_div_mod(&num1, &num2);
	printf("\t\nResultado da divisão: %d", num1);
	printf("\t\nResultado do resto da divisão: %d", num2);
}
