/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap1.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jofreire <jofreire@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/16 15:13:45 by jofreire          #+#    #+#             */
/*   Updated: 2026/03/16 15:13:45 by jofreire         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *b;
	*b = temp;
}

/*int	main(void)
{
	int	nun_a;
	int	nun_b;
	int	*a;
	int	*b;

	nun_a = 42;
	nun_b = 24;
	printf("original\n");
	printf("a vale %d\n", nun_a);
	printf("b vale %d\n", nun_b);
	a = &nun_a;
	b = &nun_b;
	ft_swap(a, b);
	printf("trocado\n");
	printf("a vale %d\n", *a);
	printf("b vale %d\n", *b);
	return (0);
}*/
