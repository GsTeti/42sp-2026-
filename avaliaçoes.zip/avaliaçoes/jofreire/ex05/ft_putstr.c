/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jofreire <jofreire@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/16 17:15:01 by jofreire          #+#    #+#             */
/*   Updated: 2026/03/16 20:13:48 by jofreire         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <unistd.h>

void	ft_putstr(char *str)
{
	int	tam;

	tam = 0;
	while (str[tam] != '\0')
	{
	tam++;
	}
	write(1, str, tam);
}

/*int	main(void)
{
	char	text[] = "Text rr\n";
	ft_putstr(text);
	return (0);
}*/
