/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jofreire <jofreire@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/03/14 14:07:55 by jofreire          #+#    #+#             */
/*   Updated: 2026/03/16 20:03:03 by jofreire         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

void	ft_ft(int *nbr)
{
	int	alvo;

	alvo = 42;
	nbr = &alvo;
}

/*int	main(void)
{
	int	nbr;

	nbr = 56;
	ft_ft(&nbr);
	printf("%d\n", nbr);
	return (0);
}*/
